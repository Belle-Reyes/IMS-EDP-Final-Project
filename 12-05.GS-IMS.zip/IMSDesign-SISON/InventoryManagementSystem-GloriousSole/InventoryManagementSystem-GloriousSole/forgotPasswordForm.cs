﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class forgotPasswordForm : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\reyes\Downloads\Ims + Desing\IMSDesign-SISON\InventoryManagementSystem-GloriousSole\SQL InventoryManagementSystem-GloriousSole\GS_IMS.mdf"";Integrated Security=True;Connect Timeout=30";

        public forgotPasswordForm()
        {
            InitializeComponent();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    using (SqlCommand cm = new SqlCommand("SELECT * FROM Users WHERE Username=@username", con))
                    {
                        cm.Parameters.AddWithValue("@username", txtEmail.Text);
                        con.Open();

                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            if(dr.Read())
                                {
                                string role = dr["Role"].ToString();

                                if (role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                                {
                                    MessageBox.Show($"Welcome {txtEmail.Text} (Admin)", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    dashboardForm main = new dashboardForm();
                                    this.Hide();
                                    main.ShowDialog();
                                }
                                else
                                {
                                    MessageBox.Show($"Welcome {txtEmail.Text}", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    dashboardForm main = new dashboardForm();
                                    this.Hide();
                                    main.ShowDialog();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid username!", "ACCESS DENIED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                txtEmail.Clear();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            loginForm lF = new loginForm();
            this.Hide();
            lF.ShowDialog();
        }
    }
}