﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class actioncommitConfirmation : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\reyes\Downloads\Ims + Desing\IMSDesign-SISON\InventoryManagementSystem-GloriousSole\SQL InventoryManagementSystem-GloriousSole\GS_IMS.mdf"";Integrated Security=True;Connect Timeout=30";
        SqlConnection con;
        SqlCommand cm;
        SqlDataReader dr;
        public actioncommitConfirmation()
        {
            InitializeComponent();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            string password = txtAdminPassword.Text;

            con = new SqlConnection(connectionString);
            con.Open();

            cm = new SqlCommand("SELECT * FROM Users WHERE Role = 'Admin' AND PasswordHash = @Password", con);
            cm.Parameters.AddWithValue("@Password", password);
            dr = cm.ExecuteReader();


            if (dr.Read())
            {

                MessageBox.Show("Changes successful!", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                updateInventoryForm ui = new updateInventoryForm();
                this.Hide();
                ui.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid password!", "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAdminPassword.Clear();
                con.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            updateInventoryForm ui = new updateInventoryForm();
            this.Hide();
            ui.ShowDialog();
        }
    }
}
