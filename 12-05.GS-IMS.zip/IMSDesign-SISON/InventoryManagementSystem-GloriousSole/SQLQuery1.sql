﻿
select * from Inventory
select * from Logs
Select * from Users