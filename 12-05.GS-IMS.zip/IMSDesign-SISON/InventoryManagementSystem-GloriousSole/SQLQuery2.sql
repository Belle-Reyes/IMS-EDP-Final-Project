﻿/*To enable the **role** and **username** to be accessible globally throughout the application lifecycle, you can use one of the following approaches, depending on your project requirements:

---

### **Option 1: Use a Static Class**
You can create a static class to store the `Username` and `Role` as global properties. A static class is accessible across all forms and classes in your application.

#### Implementation
1. Create a new static class named `UserSession`:
    ```csharp
    public static class UserSession
    {
        public static string Username { get; set; }
        public static string Role { get; set; }
    }
    ```

2. Set these properties when the user logs in:
    ```csharp
    private void Login()
    {
        // After validating user credentials:
        UserSession.Username = "LoggedInUsername";
        UserSession.Role = "UserRole";
        
        // Proceed to the next form.
        var dashboard = new dashboardForm();
        dashboard.Show();
        this.Hide();
    }
    ```

3. Access them anywhere in the application:
    ```csharp
    string username = UserSession.Username;
    string role = UserSession.Role;
    ```

---

### **Option 2: Use a Singleton Class**
A singleton ensures only one instance of the user session exists during the application's runtime.

#### Implementation
1. Create a `UserSession` singleton class:
    ```csharp
    public class UserSession
    {
        private static UserSession _instance;

        public string Username { get; set; }
        public string Role { get; set; }

        private UserSession() { }

        public static UserSession Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserSession();
                }
                return _instance;
            }
        }
    }
    ```

2. Set the session properties upon login:
    ```csharp
    private void Login()
    {
        // After validating user credentials:
        UserSession.Instance.Username = "LoggedInUsername";
        UserSession.Instance.Role = "UserRole";
        
        // Proceed to the next form.
        var dashboard = new dashboardForm();
        dashboard.Show();
        this.Hide();
    }
    ```

3. Access the session anywhere:
    ```csharp
    string username = UserSession.Instance.Username;
    string role = UserSession.Instance.Role;
    ```

---

### **Option 3: Use Application Settings**
You can store the session information in application-level variables provided by `Application`.

#### Implementation
1. Add properties to the `Program.cs` or `Main` class:
    ```csharp
    public static class Program
    {
        public static string Username { get; set; }
        public static string Role { get; set; }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());
        }
    }
    ```

2. Set the properties after login:
    ```csharp
    private void Login()
    {
        // After validating user credentials:
        Program.Username = "LoggedInUsername";
        Program.Role = "UserRole";
        
        // Proceed to the next form.
        var dashboard = new dashboardForm();
        dashboard.Show();
        this.Hide();
    }
    ```

3. Access the properties anywhere:
    ```csharp
    string username = Program.Username;
    string role = Program.Role;
    ```

---

### **Option 4: Dependency Injection (Advanced)**
Use Dependency Injection (DI) to pass the session state between forms or services. This approach is cleaner but requires a DI framework or custom implementation.

---

### Recommended Approach
For simplicity and maintainability, **Option 1 (Static Class)** is recommended for most small to medium-sized applications. It keeps your code straightforward and avoids unnecessary complexity while ensuring global accessibility.
*/

select * from inventory

