﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class changePasswordForm : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\reyes\Downloads\Ims + Desing\IMSDesign-SISON\InventoryManagementSystem-GloriousSole\SQL InventoryManagementSystem-GloriousSole\GS_IMS.mdf"";Integrated Security=True;Connect Timeout=30";
        SqlConnection con;
        SqlCommand cm;
        SqlDataReader dr;

        public changePasswordForm()
        {
            InitializeComponent();
            con = new SqlConnection(connectionString);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            manageAccountForm ma = new manageAccountForm();
            this.Hide();
            ma.ShowDialog();
        }

        private void btnChangePassword_Click_1(object sender, EventArgs e)
        {
            try
            {
                cm = new SqlCommand("SELECT * FROM Users WHERE PasswordHash = @oldpassword", con);
                cm.Parameters.AddWithValue("@oldpassword", txtOldPassword.Text);
                con.Open();
                dr = cm.ExecuteReader();

                if (dr.Read())
                {
                    dr.Close();

                    cm = new SqlCommand("UPDATE Users SET PasswordHash = @newPassword WHERE PasswordHash = @oldPassword", con);
                    cm.Parameters.AddWithValue("@oldPassword", txtOldPassword.Text);
                    cm.Parameters.AddWithValue("@newPassword", txtNewPassword.Text);
                    cm.ExecuteNonQuery();

                    MessageBox.Show("Password changed successfully.");
                    manageAccountForm main = new manageAccountForm();
                    this.Hide();
                    main.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Invalid old password.");
                    txtNewPassword.Clear();
                    txtOldPassword.Clear();
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}