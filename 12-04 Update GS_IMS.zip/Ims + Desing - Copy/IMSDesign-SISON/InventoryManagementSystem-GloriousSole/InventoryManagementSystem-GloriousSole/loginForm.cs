﻿using InventoryManagementSystem_GloriousSole;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class loginForm : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\reyes\Downloads\Ims + Desing\IMSDesign-SISON\InventoryManagementSystem-GloriousSole\SQL InventoryManagementSystem-GloriousSole\GS_IMS.mdf"";Integrated Security=True;Connect Timeout=30";
        SqlConnection con;
        SqlCommand cm;
        SqlDataReader dr;

        public loginForm()
        {
            InitializeComponent();
            con = new SqlConnection(connectionString);
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                cm = new SqlCommand("SELECT * FROM Users WHERE Username=@username AND PasswordHash=@password", con);
                cm.Parameters.AddWithValue("@username", txtUsername.Text);
                cm.Parameters.AddWithValue("@password", txtPassword.Text);
                con.Open();
                dr = cm.ExecuteReader();

                if (dr.Read())
                {
                    string role = dr["Role"].ToString();

                    if (role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show($"Welcome {txtUsername.Text} (Admin)", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        adminViewPendingLogs req = new adminViewPendingLogs();
                        this.Hide();
                        req.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show($"Welcome {txtUsername.Text}", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dashboardForm main = new dashboardForm();
                        this.Hide();
                        main.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid username or password!", "ACCESS DENIED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtUsername.Clear();
                    txtPassword.Clear();
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void btnForgotPassword_Click(object sender, EventArgs e)
        {
            forgotPasswordForm fp = new forgotPasswordForm();
            this.Hide();
            fp.ShowDialog();
        }
    }
}
