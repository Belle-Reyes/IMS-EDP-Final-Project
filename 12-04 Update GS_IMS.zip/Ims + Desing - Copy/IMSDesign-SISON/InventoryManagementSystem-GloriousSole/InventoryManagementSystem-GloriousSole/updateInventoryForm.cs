﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class updateInventoryForm : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\reyes\Downloads\Ims + Desing\IMSDesign-SISON\InventoryManagementSystem-GloriousSole\SQL InventoryManagementSystem-GloriousSole\GS_IMS.mdf"";Integrated Security=True;Connect Timeout=30";
        SqlConnection con;
        SqlCommand cm;
        SqlDataReader dr;
        public updateInventoryForm()
        {
            InitializeComponent();
            LogUserAction();
            LoadItems();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashboardForm d = new dashboardForm();
            this.Hide();
            d.ShowDialog();
        }

        private void btnViewInventory_Click(object sender, EventArgs e)
        {
            viewInventoryForm vi = new viewInventoryForm();
            this.Hide();
            vi.ShowDialog();
        }

        private void btnInvoiceLogs_Click(object sender, EventArgs e)
        {
            invoiceLogsForm il = new invoiceLogsForm();
            this.Hide();
            il.ShowDialog();
        }

        private void btnManageAccount_Click(object sender, EventArgs e)
        {
            manageAccountForm ma = new manageAccountForm();
            this.Hide();
            ma.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            /*private void btnRemove_Click(object sender, EventArgs e)
{
    try
    {
        string selectedItem = comboBoxItem.Text;
        if (!string.IsNullOrEmpty(selectedItem))
        {
            con = new SqlConnection(connectionString);
            con.Open();

            string query = "DELETE FROM Inventory WHERE Item = @Item";
            cm = new SqlCommand(query, con);
            cm.Parameters.AddWithValue("@Item", selectedItem);

            int result = cm.ExecuteNonQuery();
            con.Close();

            if (result > 0)
            {
                MessageBox.Show("Item removed successfully.");
                LogUserAction("Removed item: " + selectedItem, "Pending");
                LoadItems();
            }
            else
            {
                MessageBox.Show("Item not found or already removed.");
            }
        }
        else
        {
            MessageBox.Show("Please select an item to remove.");
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show("Error: " + ex.Message);
    }
}*/
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            /* private void btnUpdate_Click(object sender, EventArgs e)
{
    try
    {
        con = new SqlConnection(connectionString);
        con.Open();

        string query = @"UPDATE Inventory SET Brand = @Brand, Model = @Model, Category = @Category, 
                        Size = @Size, Quantity = @Quantity, Price = @Price WHERE Item = @Item";

        cm = new SqlCommand(query, con);
        cm.Parameters.AddWithValue("@Item", comboBoxItem.Text);
        cm.Parameters.AddWithValue("@Brand", textBoxBrand.Text);
        cm.Parameters.AddWithValue("@Model", textBoxModel.Text);
        cm.Parameters.AddWithValue("@Category", comboBoxCategory.Text);
        cm.Parameters.AddWithValue("@Size", textBoxSize.Text);
        cm.Parameters.AddWithValue("@Quantity", textBoxQuantity.Text);
        cm.Parameters.AddWithValue("@Price", textBoxPrice.Text);

        int result = cm.ExecuteNonQuery();
        con.Close();

        if (result > 0)
        {
            MessageBox.Show("Item updated successfully.");
            LogUserAction("Updated item: " + comboBoxItem.Text, "Pending");
            LoadItems();
        }
        else
        {
            MessageBox.Show("Failed to update item. Please check your input.");
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show("Error: " + ex.Message);
    }
}*/
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string lettersOnlyPattern = @"^[A-Za-z\s]+$";
                string numbersOnlyPattern = @"^\d+(\.\d+)?$";

                if (string.IsNullOrWhiteSpace(txtBrandAdd.Text) ||
                    string.IsNullOrWhiteSpace(txtModelAdd.Text) ||
                    string.IsNullOrWhiteSpace(txtSizeAdd.Text) ||
                    string.IsNullOrWhiteSpace(txtQuantityAdd.Text) ||
                    string.IsNullOrWhiteSpace(txtPriceAdd.Text))
                {
                    MessageBox.Show("Please fill out all fields before adding the item.");
                    return;
                }

                if (!System.Text.RegularExpressions.Regex.IsMatch(txtBrandAdd.Text, lettersOnlyPattern))
                {
                    MessageBox.Show("Brand must contain only letters.");
                    return;
                }

                if (!System.Text.RegularExpressions.Regex.IsMatch(txtModelAdd.Text, lettersOnlyPattern))
                {
                    MessageBox.Show("Model must contain only letters.");
                    return;
                }

                if (!System.Text.RegularExpressions.Regex.IsMatch(txtSizeAdd.Text, numbersOnlyPattern))
                {
                    MessageBox.Show("Size must contain only numbers or decimals.");
                    return;
                }

                if (!System.Text.RegularExpressions.Regex.IsMatch(txtQuantityAdd.Text, numbersOnlyPattern))
                {
                    MessageBox.Show("Quantity must contain only numbers.");
                    return;
                }

                if (!System.Text.RegularExpressions.Regex.IsMatch(txtPriceAdd.Text, numbersOnlyPattern))
                {
                    MessageBox.Show("Price must contain only numbers or decimals.");
                    return;
                }

                con = new SqlConnection(connectionString);
                con.Open();

                string query = @"INSERT INTO Inventory (Brand, Model, Size, Quantity, Price) 
                         VALUES (@Brand, @Model, @Size, @Quantity, @Price)";

                cm = new SqlCommand(query, con);
                cm.Parameters.AddWithValue("@Brand", txtBrandAdd.Text);
                cm.Parameters.AddWithValue("@Model", txtModelAdd.Text);
                cm.Parameters.AddWithValue("@Size", txtSizeAdd.Text);
                cm.Parameters.AddWithValue("@Quantity", txtQuantityAdd.Text);
                cm.Parameters.AddWithValue("@Price", txtPriceAdd.Text);

                int result = cm.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    actioncommitConfirmation aCC = new actioncommitConfirmation();
                   // LogUserAction("Added item: " + comboBoxItem.Text, "Pending");
                    this.Hide();
                    aCC.ShowDialog();
                    LoadItems();

                    txtBrandAdd.Clear();
                    txtModelAdd.Clear();
                    txtSizeAdd.Clear();
                    txtQuantityAdd.Clear();
                    txtPriceAdd.Clear();
                }
                else
                {
                    MessageBox.Show("Failed to add item. Please check your input.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void LogUserAction()
        {
            /*private void LogUserAction(string action, string status)
{
    try
    {
        string username = "currentUsername"; // Replace with the actual method to get the current username
        string role = "currentRole";         // Replace with the actual method to get the current role
        string query = @"INSERT INTO UserActions (Username, Role, Action, Date, Status) 
                         VALUES (@Username, @Role, @Action, @Date, @Status)";

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            using (SqlCommand cm = new SqlCommand(query, con))
            {
                cm.Parameters.AddWithValue("@Username", username);
                cm.Parameters.AddWithValue("@Role", role);
                cm.Parameters.AddWithValue("@Action", action);
                cm.Parameters.AddWithValue("@Date", DateTime.Now);
                cm.Parameters.AddWithValue("@Status", status);

                con.Open();
                cm.ExecuteNonQuery();
            }
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show("Error logging user action: " + ex.Message);
    }
}*/
        }

        private void LoadItems()
        {
            try
            {
                con = new SqlConnection(connectionString);
                con.Open();

                string query = "SELECT DISTINCT Brand, Model FROM Inventory";
                cm = new SqlCommand(query, con);
                dr = cm.ExecuteReader();

                cbItemsRemove.Items.Clear();
                cbItemUpdate.Items.Clear();

                while (dr.Read())
                {

                    string brand = dr["Brand"].ToString();
                    string model = dr["Model"].ToString();

                    if (!string.IsNullOrEmpty(brand) && !string.IsNullOrEmpty(model))
                    {
                        cbItemsRemove.Items.Add($"{brand} - {model}");
                        cbItemUpdate.Items.Add($"{brand} - {model}");
                    }
                }

                dr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading items: " + ex.Message);
            }
        }
    }
}
