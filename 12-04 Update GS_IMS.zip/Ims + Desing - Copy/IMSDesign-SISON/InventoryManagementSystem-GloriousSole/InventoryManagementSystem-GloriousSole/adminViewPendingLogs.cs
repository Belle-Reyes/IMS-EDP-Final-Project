﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class adminViewPendingLogs : Form
    {
        public adminViewPendingLogs()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnViewInventory_Click(object sender, EventArgs e)
        {
            viewInventoryForm vi = new viewInventoryForm();
            this.Hide();
            vi.ShowDialog();
        }

        private void btnUpdateInventory_Click(object sender, EventArgs e)
        {
            updateInventoryForm ui = new updateInventoryForm();
            this.Hide();
            ui.ShowDialog();
        }

        private void btnInvoiceLogs_Click(object sender, EventArgs e)
        {
            invoiceLogsForm il = new invoiceLogsForm();
            this.Hide();
            il.ShowDialog();
        }

        private void btnManageAccount_Click(object sender, EventArgs e)
        {
            manageAccountForm ma = new manageAccountForm();
            this.Hide();
            ma.ShowDialog();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {

        }
    }
}
