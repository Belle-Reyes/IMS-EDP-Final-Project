﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.NetworkInformation;
using System.Windows.Forms;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class viewInventoryForm : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\reyes\Downloads\Ims + Desing\IMSDesign-SISON\InventoryManagementSystem-GloriousSole\SQL InventoryManagementSystem-GloriousSole\GS_IMS.mdf"";Integrated Security=True;Connect Timeout=30";
        SqlConnection con;
        SqlCommand cm;
        SqlDataReader dr;
        public viewInventoryForm()
        {
            InitializeComponent();
            InitializeSortComboBox();
            LoadData();
        }

        private void InitializeSortComboBox()
        {
            cbSortBy.Items.Add("Recently Updated");
            cbSortBy.Items.Add("A-Z");
            cbSortBy.Items.Add("Z-A");
            cbSortBy.Items.Add("Price (Low to High)");
            cbSortBy.Items.Add("Price (High to Low)");
            cbSortBy.SelectedIndex = 1;
        }

        private void LoadData(string sortOrder = "A-Z")
        {
            con = new SqlConnection(connectionString);
            cm = new SqlCommand();
            cm.Connection = con;

            try
            {
                con.Open();
                string query = @"SELECT DISTINCT Brand, Model, Size, Quantity, Category, Price, UpdatedAt
                                 FROM Inventory";

                if (sortOrder == "A-Z")
                {
                    query += " ORDER BY Brand ASC";
                }
                else if (sortOrder == "Z-A")
                {
                    query += " ORDER BY Brand DESC";
                }
                else if (sortOrder == "Price (Low to High)")
                {
                    query += " ORDER BY Price ASC";
                }
                else if (sortOrder == "Price (High to Low)")
                {
                    query += " ORDER BY Price DESC";
                }
                else if (sortOrder == "Recently Updated")
                {
                    query += " ORDER BY UpdatedAt DESC";
                }

                cm.CommandText = query;

                SqlDataAdapter da = new SqlDataAdapter(cm);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvInventoryView.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashboardForm d = new dashboardForm();
            this.Hide();
            d.ShowDialog();
        }

        private void btnUpdateInventory_Click(object sender, EventArgs e)
        {
            updateInventoryForm ui = new updateInventoryForm();
            this.Hide();
            ui.ShowDialog();
        }

        private void btnInvoiceLogs_Click(object sender, EventArgs e)
        {
            invoiceLogsForm il = new invoiceLogsForm();
            this.Hide();
            il.ShowDialog();
        }

        private void btnManageAccount_Click(object sender, EventArgs e)
        {
            manageAccountForm ma = new manageAccountForm();
            this.Hide();
            ma.ShowDialog();
        }

        private void cbSortBy_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string selectedSortOrder = cbSortBy.SelectedItem.ToString();
            LoadData (selectedSortOrder);
        }
    }
}